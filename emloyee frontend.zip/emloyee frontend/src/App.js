
import './App.css';
import Listcomponnets from './Listcomponnets';


function App() {
  return (
    <div>
    <Listcomponnets/>
    </div>
  );
}

export default App;
