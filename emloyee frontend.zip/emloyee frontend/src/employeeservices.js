import axios from 'axios'

const Employee_API_URL = "http://localhost:8080/api/employee";

class employeeservices {
    getemployee() {
        return axios.get(Employee_API_URL);
    }
}
export default  new employeeservices();